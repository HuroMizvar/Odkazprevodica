package sk.miro.blocky.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.RemoveCircleOutline
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.ui.draw.alpha
import androidx.compose.material3.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sk.miro.blocky.data.ItemEntity
import sk.miro.blocky.data.ReceiptEntity
import sk.miro.blocky.data.ReceiptListRow
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.ui.graphics.Color

import sk.miro.blocky.domain.Analytics
import sk.miro.blocky.domain.Category
import sk.miro.blocky.domain.BudgetPlanner
import sk.miro.blocky.domain.CustomCategories
import androidx.compose.material.icons.filled.AutoAwesome
import sk.miro.blocky.domain.MerchantType
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** Suma, ktorá sa započítava (bez prečiarknutých položiek). */
val ReceiptListRow.counted: Long get() = countedCents ?: receipt.totalCents

private val DT = DateTimeFormatter.ofPattern("d. M. yyyy HH:mm")
private val DAY_SK = DateTimeFormatter.ofPattern("EEE d. M. · HH:mm", SK)
private val DAY_EN = DateTimeFormatter.ofPattern("EEE d. M. · HH:mm", java.util.Locale.ENGLISH)
private val DAY get() = if (sk.miro.blocky.domain.I18n.english) DAY_EN else DAY_SK
fun fmtDate(ms: Long): String = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).format(DT)
private val DM = DateTimeFormatter.ofPattern("d. M.")

/** Pondelok týždňa, do ktorého nákup patrí. */
fun weekStart(ms: Long): java.time.LocalDate =
    Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate()
        .with(java.time.temporal.TemporalAdjusters.previousOrSame(java.time.DayOfWeek.MONDAY))

/** „Týždeň 41 · 6. 10. – 12. 10.“ – dni orezané na daný mesiac. */
fun weekLabel(start: java.time.LocalDate, month: java.time.YearMonth): String {
    val from = maxOf(start, month.atDay(1)); val to = minOf(start.plusDays(6), month.atEndOfMonth())
    val wk = start.get(java.time.temporal.IsoFields.WEEK_OF_WEEK_BASED_YEAR)
    return "Týždeň $wk · ${from.format(DM)} – ${to.format(DM)}"
}

private fun fmtDay(ms: Long): String = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).format(DAY)

private fun pad(p: PaddingValues) =
    PaddingValues(start = 20.dp, end = 20.dp, top = p.calculateTopPadding(), bottom = p.calculateBottomPadding() + 24.dp)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ReceiptsScreen(vm: MainViewModel, contentPadding: PaddingValues, onOpen: (Long) -> Unit,
                   actions: @Composable RowScope.() -> Unit) {
    val all by vm.receiptList.collectAsState()
    val pending by vm.openPending.collectAsState()
    var query by rememberSaveable { mutableStateOf("") }
    val q = sk.miro.blocky.domain.Categorizer.normalize(query).trim()
    val itemRows by vm.allRows.collectAsState()
    // vyhľadávanie podľa obchodu aj podľa položiek (všetky slová dotazu musia sedieť)
    val words = remember(q) { q.split(' ').filter { it.isNotBlank() } }
    val hits = remember(q, itemRows) {
        if (words.isEmpty()) emptyMap()
        else itemRows.filter { r ->
            val n = r.normName.ifEmpty { sk.miro.blocky.domain.Categorizer.normalize(r.name) }
            words.all { w -> n.contains(w) }
        }
            .groupBy { it.receiptDbId }
    }
    val receipts = if (words.isEmpty()) all else all.filter {
        val m = sk.miro.blocky.domain.Categorizer.normalize(it.receipt.merchantName)
        words.all { w -> m.contains(w) } || hits.containsKey(it.receipt.id)
    }
    val grouped = receipts.groupBy { Analytics.monthOf(it.receipt.issuedAt) }
    // bloček, ktorý sa z eKasa nepodarilo načítať → ručný záznam (pri offline QR so sumou a dátumom z QR kódu)
    var manualFor by remember { mutableStateOf<sk.miro.blocky.data.PendingScanEntity?>(null) }
    manualFor?.let { p ->
        val off = sk.miro.blocky.data.EkasaQr.parse(p.raw) as? sk.miro.blocky.data.EkasaQr.Offline
        val cents = off?.totalAmount?.replace(',', '.')?.toDoubleOrNull()?.let { Math.round(it * 100) }
        val at = off?.issueDate?.atZone(ZoneId.systemDefault())?.toInstant()?.toEpochMilli() ?: p.createdAt
        ManualEntryDialog(onDismiss = { manualFor = null }, title = "Ručný záznam bločku", initialCents = cents) { m, c, cat ->
            vm.addManual(m, c, cat, at); vm.deletePending(p.raw); manualFor = null
        }
    }
    LazyColumn(Modifier.fillMaxSize().background(Pal.Bg), contentPadding = pad(contentPadding)) {
        item { ScreenTitle("Bločky", actions = actions) }
        if (all.isEmpty() && pending.isEmpty()) {
            item {
                BCard(Modifier.padding(top = 12.dp)) {
                    Text("Zatiaľ žiadne bločky", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("Naskenujte prvý bloček zeleným tlačidlom Skenuj dole.", fontSize = 14.sp, color = Pal.Muted)
                }
            }
        }
        if (all.size > 3) item {
            // vyhľadávanie podľa obchodu alebo položky
            Row(Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(16.dp)).background(Pal.Card)
                .padding(start = 14.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Search, null, tint = Pal.Muted, modifier = Modifier.size(20.dp))
                androidx.compose.foundation.text.BasicTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 15.sp, color = Pal.Ink, fontFamily = Jakarta),
                    modifier = Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 14.dp),
                    decorationBox = { inner ->
                        if (query.isEmpty()) Text("Hľadať obchod alebo položku…", fontSize = 15.sp, color = Pal.Faint)
                        inner()
                    })
                if (query.isNotEmpty()) IconButton(onClick = { query = "" }) {
                    Icon(Icons.Default.Close, "Vymazať", tint = Pal.Muted, modifier = Modifier.size(20.dp))
                }
            }
        }
        if (q.isNotBlank()) item {
            Text(if (receipts.isEmpty()) "Nič sa nenašlo." else "Nájdené: ${receipts.size} ${receiptWord(receipts.size)} · spolu ${eur(receipts.sumOf { it.counted })}",
                Modifier.padding(top = 10.dp, start = 4.dp), fontSize = 13.sp, color = Pal.Muted, fontWeight = FontWeight.SemiBold)
            val itemHits = hits.values.flatten()
            if (itemHits.isNotEmpty()) Text("Položky „$query“: ${itemHits.size}× · spolu ${eur(itemHits.sumOf { it.priceCents })}",
                Modifier.padding(top = 2.dp, start = 4.dp), fontSize = 13.sp, color = Pal.Green, fontWeight = FontWeight.Bold)
        }
        if (pending.isNotEmpty()) {
            item { SectionHeader("Čaká na načítanie (${pending.size})") }
            item {
                BCard(padding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)) {
                    pending.forEach { p ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(38.dp).clip(CircleShape).background(
                                if (p.status == "FAILED") Pal.RedSoft else Pal.AmberSoft), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Schedule, null, tint = if (p.status == "FAILED") Pal.Red else Pal.Amber,
                                    modifier = Modifier.size(20.dp))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(if (p.status == "FAILED") "Nepodarilo sa načítať" else "Načíta sa automaticky",
                                    fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Text(fmtDate(p.createdAt) + (p.message?.let { " · $it" } ?: ""), fontSize = 12.sp,
                                    color = Pal.Muted, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                            if (p.status == "FAILED") TextButton(onClick = { manualFor = p }) { Text("Zadať ručne", color = Pal.Green) }
                            IconButton(onClick = { vm.deletePending(p.raw) }) { Icon(Icons.Default.Delete, "Odstrániť", tint = Pal.Muted) }
                        }
                    }
                }
            }
        }
        grouped.forEach { (month, list) ->
            // hlavička mesiaca ostáva prilepená hore pri posúvaní
            stickyHeader(key = "h$month") {
                Row(Modifier.fillMaxWidth().background(Pal.Bg).padding(top = 16.dp, bottom = 8.dp, start = 4.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(monthLabel(month), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                        sk.miro.blocky.domain.Period.rangeLabel(month)?.let { Text(it, fontSize = 12.sp, color = Pal.Muted) }
                        Text("${list.size} ${receiptWord(list.size)}", fontSize = 12.sp, color = Pal.Muted)
                    }
                    Text(eur(list.sumOf { it.counted }), fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
            // v rámci mesiaca po týždňoch (pondelok–nedeľa, orezané na daný mesiac)
            list.groupBy { weekStart(it.receipt.issuedAt) }.forEach { (wStart, wList) ->
                item(key = "w$month-$wStart") {
                    Row(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 6.dp, start = 4.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(weekLabel(wStart, month), Modifier.weight(1f), fontSize = 12.sp,
                            fontWeight = FontWeight.Bold, color = Pal.Muted)
                        Text(eur(wList.sumOf { it.counted }), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Pal.Muted)
                    }
                }
                item(key = "c$month-$wStart") {
                    BCard(Modifier.padding(bottom = 10.dp), padding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)) {
                        wList.forEachIndexed { i, r ->
                            if (i > 0) HorizontalDivider(Modifier.padding(start = 62.dp, end = 10.dp), color = Pal.Track)
                            ReceiptRow(r, hits[r.receipt.id].orEmpty()) { onOpen(r.receipt.id) }
                        }
                    }
                }
            }
        }
    }
}

fun receiptWord(n: Int) = when { n == 1 -> "bloček"; n in 2..4 -> "bločky"; else -> "bločkov" }
private fun itemWord(n: Int) = when { n == 1 -> "položka"; n in 2..4 -> "položky"; else -> "položiek" }

@Composable
private fun ReceiptRow(row: ReceiptListRow, hits: List<sk.miro.blocky.data.ItemRow> = emptyList(), onClick: () -> Unit) {
    val r = row.receipt
    val edited = row.editedCount > 0
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(16.dp))
        .background(if (edited) Pal.AmberSoft.copy(alpha = 0.55f) else Color.Transparent)
        .clickable(onClick = onClick)
        .padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        if (r.source == "MANUAL") CatBadge(Category.fromName(row.mainCategory ?: "INE"), 42)
        else MerchantBadge(MerchantType.fromName(r.merchantType), 42)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(shortMerchant(r.merchantName), fontSize = 15.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(fmtDay(r.issuedAt) + (if (row.itemCount > 0) " · ${row.itemCount} ${itemWord(row.itemCount)}" else "") +
                    when (r.source) { "MANUAL" -> " · ručne"; "DEMO" -> " · demo"; else -> "" },
                fontSize = 12.sp, color = Pal.Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            r.addedBy?.let { who ->
                Row(Modifier.padding(top = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    MemberDot(who, 14)
                    Spacer(Modifier.width(4.dp))
                    Text(who, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = memberColor(who))
                }
            }
            if (edited) EditedChip(Modifier.padding(top = 4.dp))
            // nájdené položky pri vyhľadávaní
            hits.take(3).forEach { h ->
                Text("• ${h.name} · ${eur(h.priceCents)}", fontSize = 12.sp, color = Pal.Green, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
            }
            if (hits.size > 3) Text("+ ďalšie ${hits.size - 3}", fontSize = 11.sp, color = Pal.Muted)
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            if (row.counted < 0) Text("+" + eur(-row.counted), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Pal.Green)
            else Text(eur(row.counted), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
            if (row.counted != r.totalCents) Text(eur(r.totalCents), fontSize = 11.sp, color = Pal.Muted,
                textDecoration = TextDecoration.LineThrough)
        }
    }
}

/** Jemné označenie ručne upraveného bločku / položky. */
@Composable
fun EditedChip(modifier: Modifier = Modifier, text: String = "upravený") {
    Row(modifier.clip(RoundedCornerShape(6.dp)).background(Pal.AmberSoft).padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Edit, null, tint = Pal.Amber, modifier = Modifier.size(11.dp))
        Spacer(Modifier.width(3.dp))
        Text(text, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Pal.Amber)
    }
}

@Composable
fun ReceiptDetailScreen(vm: MainViewModel, id: Long, onBack: () -> Unit) {
    val data by vm.repo.receipt(id).collectAsState(initial = null)
    var editingId by remember { mutableStateOf<Long?>(null) }
    var editManual by remember { mutableStateOf(false) }
    var pickingFor by remember { mutableStateOf<ItemEntity?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var changeType by remember { mutableStateOf(false) }

    Scaffold(containerColor = Pal.Bg) { pad ->
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 20.dp, end = 20.dp,
            top = pad.calculateTopPadding(), bottom = pad.calculateBottomPadding() + 24.dp)) {
            item {
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack, Modifier.offset(x = (-12).dp)) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Späť")
                    }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.Delete, "Zmazať bloček", tint = Pal.Muted) }
                }
            }
            val d = data ?: return@LazyColumn
            item {
                BCard {
                    val mType = MerchantType.fromName(d.receipt.merchantType)
                    if (d.receipt.source != "MANUAL") Row(Modifier.clip(RoundedCornerShape(12.dp)).clickable { changeType = true }
                        .padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        MerchantBadge(mType, 36)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(mType.label, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = merchantStyle(mType).fg)
                            Text("Zmeniť typ prevádzky", fontSize = 12.sp, color = Pal.Muted)
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(shortMerchant(d.receipt.merchantName), Modifier.weight(1f), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                        if (d.receipt.source == "MANUAL") TextButton(onClick = { editManual = true }) {
                            Icon(Icons.Default.Edit, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Upraviť")
                        }
                    }
                    Text(fmtDate(d.receipt.issuedAt), fontSize = 13.sp, color = Pal.Muted)
                    d.receipt.addedBy?.let { who ->
                        Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            MemberDot(who, 18)
                            Spacer(Modifier.width(6.dp))
                            Text("Nahral(a): $who", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = memberColor(who))
                        }
                    }
                    d.receipt.storeAddress?.let { Text(it, fontSize = 13.sp, color = Pal.Muted) }
                    Spacer(Modifier.height(10.dp))
                    val counted = d.items.filter { !it.excluded }.sumOf { it.priceCents }
                    val excludedN = d.items.count { it.excluded }
                    val saved = d.items.sumOf { it.discountCents }
                    val editedN = d.items.count { it.edited }
                    Text(eur(if (editedN > 0) counted else d.receipt.totalCents), fontSize = 34.sp,
                        fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.5).sp)
                    if (editedN > 0) {
                        EditedChip(Modifier.padding(top = 2.dp, bottom = 4.dp), "upravený bloček")
                        Text("Započítané po úpravách · na bločku ${eur(d.receipt.totalCents)}" +
                                (if (excludedN > 0) " · prečiarknuté $excludedN" else ""),
                            fontSize = 12.sp, color = Pal.Amber)
                    }
                    if (saved > 0) Text("Na zľavách ste ušetrili ${eur(saved)}", fontSize = 12.sp,
                        color = Pal.Green, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(2.dp))
                    Text("${d.items.size} ${itemWord(d.items.size)} · ťuknutím na položku zmeníte kategóriu alebo počet kusov, " +
                        "ikonou vpravo ju prečiarknete", fontSize = 12.sp, color = Pal.Muted, lineHeight = 16.sp)
                }
            }
            item { Spacer(Modifier.height(12.dp)) }
            item {
                BCard(padding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) {
                    d.items.forEach { item ->
                        val c = Category.fromName(item.category)
                        val ex = item.excluded
                        val strike = if (ex) TextDecoration.LineThrough else TextDecoration.None
                        val qtyChanged = item.origQuantity != null
                        Row(Modifier.fillMaxWidth().padding(vertical = 1.dp).clip(RoundedCornerShape(16.dp))
                            .background(if (item.edited) Pal.AmberSoft.copy(alpha = 0.55f) else Color.Transparent)
                            .clickable { editingId = item.id }
                            .padding(start = 8.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.alpha(if (ex) 0.4f else 1f)) { CatBadge(c, 34) }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.name, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textDecoration = strike,
                                    color = if (ex) Pal.Muted else Pal.Ink)
                                val qty = when {
                                    qtyChanged -> "${fmtQty(item.quantity)} z ${fmtQty(item.origQuantity!!)} ks · "
                                    item.quantity != 1.0 -> "${fmtQty(item.quantity)} × · "
                                    else -> ""
                                }
                                Text(if (ex) "Nezapočítané – vrátené / reklamované"
                                     else qty + c.label + when {
                                         item.categoryManual -> " · upravené"
                                         item.catSource == "nano" -> " · AI telefónu"
                                         item.catSource == "ai" -> " · AI"
                                         else -> ""
                                     },
                                    fontSize = 12.sp, color = if (ex) Pal.Muted else catStyle(c).fg)
                                if (qtyChanged && !ex) Text("na bločku ${eur(item.origPriceCents ?: item.priceCents)} · počet upravený",
                                    fontSize = 12.sp, color = Pal.Amber, fontWeight = FontWeight.SemiBold)
                                if (item.discountCents > 0 && !ex) Text(
                                    "zľava −${eur(item.discountCents)} · pôvodne ${eur(item.priceCents + item.discountCents)}",
                                    fontSize = 12.sp, color = Pal.Green, fontWeight = FontWeight.SemiBold)
                            }
                            Text(eur(item.priceCents), fontSize = 14.sp, fontWeight = FontWeight.Bold, textDecoration = strike,
                                color = if (ex) Pal.Muted else Pal.Ink)
                            IconButton(onClick = { vm.setExcluded(item.id, !ex) }) {
                                Icon(if (ex) Icons.AutoMirrored.Filled.Undo else Icons.Default.RemoveCircleOutline,
                                    if (ex) "Znova započítať" else "Prečiarknuť – nezapočítať",
                                    tint = if (ex) Pal.Green else Pal.Faint, modifier = Modifier.size(22.dp))
                            }
                        }
                    }
                }
            }
            if (data?.receipt?.source == "EKASA") item { GovSourceNote(Modifier.padding(top = 20.dp)) }
        }
    }

    val rec = data?.receipt
    if (changeType && rec?.merchantKey != null) {
        MerchantTypeDialog(
            sk.miro.blocky.data.MerchantEntity(rec.merchantKey, rec.merchantName, rec.merchantType ?: "UNKNOWN", false),
            onPick = { t -> vm.answerMerchant(sk.miro.blocky.data.MerchantEntity(rec.merchantKey, rec.merchantName, t.name, true), t); changeType = false },
            onLater = { changeType = false })
    }

    val editingItem = editingId?.let { eid -> data?.items?.firstOrNull { it.id == eid } }
    if (editingItem != null) ItemEditDialog(editingItem,
        onDismiss = { editingId = null },
        onCategory = { pickingFor = editingItem; editingId = null },
        onQuantity = { q -> vm.setQuantity(editingItem.id, q) },
        onExclude = { ex -> vm.setExcluded(editingItem.id, ex) },
        onRestore = { vm.restoreItem(editingItem.id) })
    val manualRec = data
    if (editManual && manualRec != null) {
        val it0 = manualRec.items.firstOrNull()
        ManualEntryDialog(
            onDismiss = { editManual = false },
            title = "Upraviť ručný záznam",
            initialMerchant = manualRec.receipt.merchantName.takeIf { it != "Ručný záznam" } ?: "",
            initialCents = manualRec.receipt.totalCents,
            initialCategory = Category.fromName(it0?.category ?: "INE")
        ) { m, c, cat -> vm.updateManual(id, m, c, cat); editManual = false }
    }

    pickingFor?.let { item ->
        CategoryPickerDialog(item.name, Category.fromName(item.category), onDismiss = { pickingFor = null }, onCreate = vm::createCustomCategory) { c, all ->
            vm.recategorize(item.id, item.normName, c, all); pickingFor = null
        }
    }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        containerColor = Pal.Card,
        title = { Text("Zmazať bloček?") },
        confirmButton = { TextButton(onClick = { vm.deleteReceipt(id); confirmDelete = false; onBack() }) { Text("Zmazať", color = Pal.Red) } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Zrušiť") } }
    )
}

/** Úprava položky: kategória, počet kusov, prečiarknutie, obnovenie pôvodného stavu. */
@Composable
private fun ItemEditDialog(item: ItemEntity, onDismiss: () -> Unit, onCategory: () -> Unit,
                           onQuantity: (Double) -> Unit, onExclude: (Boolean) -> Unit, onRestore: () -> Unit) {
    val c = Category.fromName(item.category)
    val origQty = item.origQuantity ?: item.quantity
    // počet sa dá meniť pri kusových položkách (celé číslo, aspoň 2 ks na bločku)
    val canQty = origQty >= 2.0 && origQty % 1.0 == 0.0 && item.priceCents > 0
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Pal.Card,
        title = { Text(item.name, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                // kategória
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Pal.Bg).clickable(onClick = onCategory)
                    .padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    CatBadge(c, 36)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(if (item.byAi) "Kategória – navrhla AI, skontrolujte" else "Kategória", fontSize = 12.sp,
                            color = if (item.byAi) Pal.Amber else Pal.Muted)
                        Text(c.label, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("Zmeniť", color = Pal.Green, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                // počet kusov
                if (canQty) Column {
                    Text("Koľko kusov ste naozaj zaplatili?", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Pal.Muted)
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val q = item.quantity
                        FilledTonalIconButton(onClick = { onQuantity(q - 1) }, enabled = q > 1.0 && !item.excluded) {
                            Icon(Icons.Default.Remove, "Menej") }
                        Text("${fmtQty(q)} z ${fmtQty(origQty)} ks", Modifier.weight(1f), fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        FilledTonalIconButton(onClick = { onQuantity(q + 1) }, enabled = q < origQty && !item.excluded) {
                            Icon(Icons.Default.Add, "Viac") }
                    }
                    Text("Započíta sa ${eur(item.priceCents)}" +
                            (item.origPriceCents?.let { " (na bločku ${eur(it)})" } ?: ""),
                        Modifier.fillMaxWidth().padding(top = 4.dp), fontSize = 13.sp,
                        color = if (item.origQuantity != null) Pal.Amber else Pal.Muted,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
                // prečiarknutie
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { onExclude(!item.excluded) }
                    .padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Nezapočítať do výdavkov", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Text("vrátené, reklamované, platil niekto iný", fontSize = 12.sp, color = Pal.Muted)
                    }
                    Switch(checked = item.excluded, onCheckedChange = { onExclude(it) })
                }
                if (item.edited) TextButton(onClick = onRestore, contentPadding = PaddingValues(0.dp)) {
                    Icon(Icons.AutoMirrored.Filled.Undo, null, tint = Pal.Amber, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Obnoviť podľa bločku", color = Pal.Amber, fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Hotovo", fontWeight = FontWeight.Bold) } }
    )
}

private fun fmtQty(q: Double): String =
    if (q % 1.0 == 0.0) q.toLong().toString() else "%.3f".format(SK, q).trimEnd('0').trimEnd(',')


@Composable
fun BudgetsScreen(vm: MainViewModel, contentPadding: PaddingValues, actions: @Composable RowScope.() -> Unit) {
    val st by vm.state.collectAsState()
    val cats by vm.catsVersion.collectAsState()   // prekresliť pri zmene vlastných kategórií
    val spent = st.report?.categories?.associate { it.category to it.cents }.orEmpty()
    val states = st.report?.categories?.associate { it.category to it.budgetState }.orEmpty()
    var proposal by remember { mutableStateOf<List<BudgetPlanner.Suggestion>?>(null) }
    var choosePeriod by remember { mutableStateOf(false) }
    var editCustom by remember { mutableStateOf<CustomCategories.Def?>(null) }
    var newCustom by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize().background(Pal.Bg), contentPadding = pad(contentPadding)) {
        item { ScreenTitle("Rozpočty", actions = actions) }
        item {
            BCard(Modifier.padding(bottom = 12.dp), color = Pal.Hero) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, null, tint = Pal.OnHero, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("Automatické rozpočty", color = Pal.OnHero, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                }
                Spacer(Modifier.height(6.dp))
                Text("Navrhnem limity podľa vybraného obdobia – o niečo nižšie, ako zvyčajne míňate, aby ste ušetrili.",
                    color = Pal.OnHeroMuted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { choosePeriod = true }, shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (AppTheme.id == ThemeId.FRESH) Pal.Highlight else Pal.Green,
                        contentColor = if (AppTheme.id == ThemeId.FRESH) Pal.OnHighlight else Pal.OnGreen)) {
                    Text("Nastaviť podľa môjho míňania", fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Text("Mesačný limit na kategóriu. Prázdne pole = bez limitu. Prekročenie sa ukáže v tipoch.",
                Modifier.padding(bottom = 12.dp), fontSize = 13.sp, color = Pal.Muted)
        }
        item {
            // skupiny kategórií, v skupine podľa abecedy; zálohy a zľavy nemajú rozpočet
            key(cats, sk.miro.blocky.domain.I18n.english) { Column {
                CATEGORY_GROUPS.map { (t, l) -> t to l.filter { it.active && it != Category.ZLAVY && it != Category.ZALOHY } }
                    .filter { it.second.isNotEmpty() }.forEach { (title, list) ->
                        val gBudget = list.sumOf { st.budgets[it] ?: 0L }
                        val gSpent = list.sumOf { spent[it] ?: 0L }
                        Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 14.dp, bottom = 6.dp),
                            verticalAlignment = Alignment.Bottom) {
                            Text(title, Modifier.weight(1f), fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                            Text(if (gBudget > 0) "${eur(gSpent)} z ${eur(gBudget)}" else "minuté ${eur(gSpent)}",
                                fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                                color = if (gBudget > 0 && gSpent > gBudget) Pal.Red else Pal.Muted)
                        }
                        BCard(padding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)) {
                            list.forEach { c ->
                                key(c) { BudgetRow(c, st.budgets[c], spent[c] ?: 0L, states[c]) { vm.setBudget(c, it) } }
                            }
                        }
                    }
            } }
        }
        item {
            Spacer(Modifier.height(20.dp))
            SectionTitle("Vlastné kategórie")
            BCard(padding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)) {
                val defs = CustomCategories.all
                if (defs.isEmpty()) Text("Zatiaľ žiadne. Vytvorte si napr. „Deti“, „Chata“ alebo „Hobby“.",
                    Modifier.padding(vertical = 10.dp), fontSize = 13.sp, color = Pal.Muted)
                defs.forEach { d ->
                    Row(Modifier.fillMaxWidth().clickable { editCustom = d }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        CatBadge(d.slot, 34); Spacer(Modifier.width(12.dp))
                        Text(d.label, Modifier.weight(1f), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Icon(Icons.Default.Edit, "Upraviť", tint = Pal.Muted, modifier = Modifier.size(20.dp))
                    }
                }
                if (defs.size < 8) TextButton(onClick = { newCustom = true }) {
                    Icon(Icons.Default.Add, null, Modifier.size(18.dp), tint = Pal.Green); Spacer(Modifier.width(6.dp))
                    Text("Nová kategória", color = Pal.Green, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (choosePeriod) BudgetPeriodDialog(vm.firstExpenseDate(), onDismiss = { choosePeriod = false }) { from, to ->
        choosePeriod = false
        proposal = vm.budgetSuggestions(from, to)
    }
    proposal?.let { list ->
        AutoBudgetDialog(list, st.budgets, onDismiss = { proposal = null }) { chosen ->
            vm.applyBudgets(chosen); proposal = null
        }
    }
    editCustom?.let { d ->
        CustomCategoryDialog(d, onDismiss = { editCustom = null },
            onDelete = { vm.deleteCustomCategory(d.slot); editCustom = null }) { name, icon, color ->
            vm.updateCustomCategory(d.slot, name, icon, color); editCustom = null
        }
    }
    if (newCustom) CustomCategoryDialog(null, onDismiss = { newCustom = false }) { name, icon, color ->
        vm.createCustomCategory(name, icon, color); newCustom = false
    }
}

fun dayWord(n: Int) = when (n) { 1 -> "deň"; in 2..4 -> "dni"; else -> "dní" }

/** Výber obdobia, z ktorého sa vypočítajú automatické rozpočty. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BudgetPeriodDialog(first: java.time.LocalDate?, onDismiss: () -> Unit,
                               onCalc: (java.time.LocalDate, java.time.LocalDate) -> Unit) {
    val today = java.time.LocalDate.now()
    val all = first ?: today
    var from by remember { mutableStateOf(all) }
    var to by remember { mutableStateOf(today) }
    var picking by remember { mutableStateOf<Int?>(null) }   // 0 = od, 1 = do
    val days = java.time.temporal.ChronoUnit.DAYS.between(from, to).toInt() + 1
    val df = java.time.format.DateTimeFormatter.ofPattern("d. M. yyyy")
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Pal.Card,
        title = { Text("Obdobie na výpočet", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Z výdavkov v tomto období vypočítam mesačný rozpočet: výdavky ÷ počet dní × 30.",
                    fontSize = 13.sp, color = Pal.Muted)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = from == all && to == today, onClick = { from = all; to = today },
                        label = { Text("Celá história") })
                    FilterChip(selected = from == today.minusDays(29) && to == today,
                        onClick = { from = maxOf(all, today.minusDays(29)); to = today }, label = { Text("30 dní") })
                    FilterChip(selected = from == today.minusMonths(3).plusDays(1) && to == today,
                        onClick = { from = maxOf(all, today.minusMonths(3).plusDays(1)); to = today }, label = { Text("3 mesiace") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { picking = 0 }, Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                        Text("Od ${from.format(df)}", maxLines = 1)
                    }
                    OutlinedButton(onClick = { picking = 1 }, Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                        Text("Do ${to.format(df)}", maxLines = 1)
                    }
                }
                Text(if (days < 1) "Dátum „od“ musí byť pred dátumom „do“."
                     else "$days ${dayWord(days)}" + (if (days < 14) " · krátke obdobie, návrh môže byť nepresný" else ""),
                    fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = if (days < 1) Pal.Red else if (days < 14) Pal.Amber else Pal.Ink)
            }
        },
        confirmButton = {
            TextButton(enabled = days >= 1, onClick = { onCalc(from, to) }) { Text("Vypočítať", fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Zrušiť") } }
    )
    picking?.let { which ->
        val zone = java.time.ZoneOffset.UTC
        val init = if (which == 0) from else to
        val state = rememberDatePickerState(initialSelectedDateMillis = init.atStartOfDay(zone).toInstant().toEpochMilli())
        DatePickerDialog(
            onDismissRequest = { picking = null },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { ms ->
                        val d = java.time.Instant.ofEpochMilli(ms).atZone(zone).toLocalDate()
                        if (which == 0) from = d else to = d
                    }
                    picking = null
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { picking = null }) { Text("Zrušiť") } }
        ) { DatePicker(state) }
    }
}

/** Návrh automatických rozpočtov – používateľ vidí priemer, návrh a odhad úspory a môže kategórie odznačiť. */
@Composable
private fun AutoBudgetDialog(list: List<BudgetPlanner.Suggestion>, current: Map<Category, Long>,
                             onDismiss: () -> Unit, onApply: (List<BudgetPlanner.Suggestion>) -> Unit) {
    val chosen = remember(list) { mutableStateMapOf<Category, Boolean>().apply { list.forEach { put(it.category, true) } } }
    val saving = list.filter { chosen[it.category] == true }.sumOf { it.savingCents }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Pal.Card,
        title = { Text("Návrh rozpočtov", fontWeight = FontWeight.Bold) },
        text = {
            if (list.isEmpty()) Text("Na návrh je zatiaľ málo údajov. Skenujte bločky aspoň týždeň, potom to skúste znova.")
            else Column {
                val months = list.maxOf { it.months }
                val days = list.maxOf { it.days }
                Text(if (days > 0) "Z obdobia $days ${dayWord(days)}, prepočítané na mesiac (30 dní)."
                     else if (months == 0) "Odhad z tohto mesiaca (zatiaľ nemáte celý mesiac)."
                     else "Z histórie $months ${if (months == 1) "mesiaca" else "mesiacov"}. Priemer → návrh na mesiac.",
                    fontSize = 13.sp, color = Pal.Muted)
                Spacer(Modifier.height(8.dp))
                Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                    list.forEach { s ->
                        Row(Modifier.fillMaxWidth().clickable { chosen[s.category] = chosen[s.category] != true }
                            .padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(chosen[s.category] == true, { chosen[s.category] = it },
                                colors = CheckboxDefaults.colors(checkedColor = Pal.Green))
                            CatBadge(s.category, 28); Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(s.category.label, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                Text("priemer ${eur(s.averageCents)}" +
                                    (current[s.category]?.let { " · teraz ${eur(it)}" } ?: ""),
                                    fontSize = 12.sp, color = Pal.Muted)
                            }
                            Text(eur(s.budgetCents), fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = Pal.Ink)
                        }
                    }
                }
                if (saving > 0) {
                    Spacer(Modifier.height(10.dp))
                    Text("Ak rozpočty dodržíte, ušetríte asi ${eur(saving)} mesačne (${eur(saving * 12)} ročne).",
                        fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Pal.Green)
                }
            }
        },
        confirmButton = {
            if (list.isNotEmpty()) TextButton(enabled = chosen.values.any { it },
                onClick = { onApply(list.filter { chosen[it.category] == true }) }) { Text("Použiť") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Zrušiť") } }
    )
}

@Composable
private fun BudgetRow(c: Category, budget: Long?, spent: Long, state: sk.miro.blocky.domain.BudgetState?, onSave: (Long?) -> Unit) {
    var text by remember(budget) { mutableStateOf(budget?.let { (it / 100).toString() } ?: "") }
    val over = budget != null && spent > budget
    val risk = !over && state == sk.miro.blocky.domain.BudgetState.RISK
    val hl = if (over) Pal.RedSoft else if (risk) Pal.AmberSoft else null
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(14.dp))
        .then(if (hl != null) Modifier.background(hl) else Modifier)
        .padding(vertical = 6.dp, horizontal = if (hl != null) 8.dp else 0.dp), verticalAlignment = Alignment.CenterVertically) {
        CatBadge(c, 34)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(c.label, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text("tento mesiac ${eur(spent)}" + when { over -> " · prekročené"; risk -> " · hrozí prekročenie"; else -> "" },
                fontSize = 12.sp, color = if (over) Pal.Red else if (risk) Pal.Amber else Pal.Muted)
        }
        OutlinedTextField(
            value = text,
            onValueChange = { v ->
                text = v.filter { it.isDigit() }.take(6)
                onSave(text.toLongOrNull()?.times(100))
            },
            modifier = Modifier.width(104.dp), singleLine = true, suffix = { Text("€") },
            shape = RoundedCornerShape(14.dp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
    }
}

/** Ručné zadanie výdavku alebo príjmu bez QR (napr. trh, bloček bez eKasa, vrátené peniaze). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManualEntryDialog(onDismiss: () -> Unit, title: String = "Ručný záznam", initialMerchant: String = "",
                      initialCents: Long? = null, initialCategory: Category = Category.INE,
                      onSave: (String, Long, Category) -> Unit) {
    var merchant by remember { mutableStateOf(initialMerchant) }
    // príjem sa ukladá ako záporná suma – zníži minuté a zvýši zostatok rozpočtu
    var income by remember { mutableStateOf((initialCents ?: 0L) < 0) }
    var amount by remember { mutableStateOf(initialCents?.let { kotlin.math.abs(it) }?.let { "%d,%02d".format(it / 100, it % 100) } ?: "") }
    var cat by remember { mutableStateOf(initialCategory) }
    var expanded by remember { mutableStateOf(false) }
    val cents = amount.replace(',', '.').toDoubleOrNull()?.let { Math.round(it * 100) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Pal.Card,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !income, onClick = { income = false }, label = { Text("Výdaj") })
                    FilterChip(selected = income, onClick = { income = true }, label = { Text("Príjem") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Pal.GreenSoft))
                }
                if (income) Text("Príjem (napr. vrátené peniaze) zníži minuté vo vybranej kategórii a zvýši zostatok rozpočtu.",
                    fontSize = 12.sp, color = Pal.Muted)
                OutlinedTextField(merchant, { merchant = it }, label = { Text("Obchod / popis") }, singleLine = true,
                    shape = RoundedCornerShape(14.dp))
                OutlinedTextField(amount, { amount = it }, label = { Text("Suma €") }, singleLine = true,
                    shape = RoundedCornerShape(14.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                Box {
                    OutlinedButton(onClick = { expanded = true }, shape = RoundedCornerShape(14.dp)) {
                        CatBadge(cat, 24); Spacer(Modifier.width(8.dp)); Text(cat.label)
                    }
                    DropdownMenu(expanded, { expanded = false }) {
                        Category.visible.sortedByLabel().forEach { c ->
                            DropdownMenuItem(text = { Text(c.label) }, leadingIcon = { CatBadge(c, 24) },
                                onClick = { cat = c; expanded = false })
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = cents != null && cents > 0, onClick = {
                onSave(merchant.ifBlank { if (income) "Príjem" else "" }, if (income) -cents!! else cents!!, cat)
            }) { Text("Uložiť") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Zrušiť") } }
    )
}
